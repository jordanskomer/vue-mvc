var gulp = require('gulp');
var sassdoc = require('sassdoc');

gulp.task('sassdoc', function () {
  var options = {
    dest: 'docs',
    verbose: true,
    display: {
      access: ['public', 'private'],
      alias: true,
      watermark: false,
    },
    groups: {
      'undefined': 'Ungrouped',
      tools: 'Tools',
      bar: 'Bar group',
    },
    basePath: 'https://github.com/SassDoc/sassdoc',
  };

  return gulp.src('**/*.scss')
    .pipe(sassdoc(options));
});

gulp.task('watch', function() {
  gulp.watch("**/*.scss", ['sassdoc']);
});

gulp.task('default', ['sassdoc', 'watch']);

