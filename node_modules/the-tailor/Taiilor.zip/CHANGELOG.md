# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)

## 2017-05-19
### Added
  - Added release-it @evanagee

## 2017-05-12
### Pull Requests
  - [Added npm support, updated readme](https://github.com/gateway-church/tailor/pull/11)

### Added
  - Added npm support @evanagee

### Updated
  - Readme to include setup instructions using npm @evanagee
  - options.scss to add !default flag to variables @evanagee

## 2017-04-10
### Pull Requests
- [Add helper classes and update docs](https://github.com/gateway-church/tailor/pull/5)

### Added
  - Clearfix. @jordanskomer
  - Transitions. @jordanskomer
  - Opacity. @jordanskomer
  - Font Size. @jordanskomer
  - Ellipsis. @jordanskomer

### Updated
  - Sassdocs. @jordanskomer

### Changed
  - Sassdocs ordering. @jordanskomer

## 2017-03-30
### Added
  - Sassdocs. @jordanskomer
  - Add gulp to updated sassdocs. @jordanskomer
  - Dye (colors). @jordanskomer

## [2017-03-24]
### Added
- Initial Commit @jordanskomer
- Base version of mannequin - @evanagee
